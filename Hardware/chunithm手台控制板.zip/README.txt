<p>使用 Arduino + mpr121 + WS2812B 制作的 Chunithm 控制器。<br />使用了Sucareto/Arduino-Chunithm-Controller（https://github.com/Sucareto/Arduino-Chunithm-Controller）的固件</p>
<p>原理：  <br />使用 mpr121 的 io 口分别连接铝箔（或其他导电物体），arduino 用 i2c 和 mpr121 通信获取触摸状态。  </p>
<p>引用库：  <br />[mpr121操作 Adafruit_MPR121.h](https://github.com/adafruit/Adafruit_MPR121)  <br />[NKRO键盘 HID-Project.h](https://github.com/NicoHood/HID)  <br />[驱动WS2812B FastLED.h](https://github.com/FastLED/FastLED)</p>            
How to use：

At editor, open the document via: Top menu - File - Open - EasyEDA... , and select the json file, then open it at the editor, you can save it into a project.


如何使用：

打开编辑器，通过：顶部菜单 - 文件 - 打开 - 立创EDA... ，选择 json 文件打开在编辑器，你可以保存文档进工程里面。